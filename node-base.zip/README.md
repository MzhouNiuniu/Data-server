node +express +mongodb  数据库表没导入 需要先在 !




![输入图片说明](https://images.gitee.com/uploads/images/2019/0828/120056_b62c958f_2045611.png "屏幕截图.png")


中修改配置

 修改数据库连接
然后依次新增用户 登录 新增信息等