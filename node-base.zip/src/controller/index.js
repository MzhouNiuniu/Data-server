exports.User = require('./user');
exports.News = require('./news');
exports.Expert = require('./expert');
exports.Organizetion = require('./organizetion');
exports.Collaborate = require('./collaborate');
exports.Statute = require('./statute');
exports.ResearchReport = require('./researchReport');
exports.ResearchScriptures = require('./researchScriptures');
exports.Magazine = require('./magazine');
exports.About = require('./about');
exports.IndexConfig = require('./indexConfig');
exports.companyData = require('./companyData');
exports.Oss = require('./oss');
exports.BasicData = require('./basicData');

