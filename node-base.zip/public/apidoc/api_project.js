define({
  "title": "cloud-server API",
  "url": "http://localhost:3000",
  "name": "cloud-server",
  "version": "1.0.0",
  "description": "cloud-server项目API文档",
  "forceLanguage": "zh-cn",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-08-09T08:34:31.632Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
