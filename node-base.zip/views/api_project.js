define({
  "title": "cloud-server API",
  "url": "http://192.168.9.105:3000",
  "name": "cloud-server",
  "version": "1.0.0",
  "description": "cloud-server项目API文档",
  "forceLanguage": "zh-cn",
  "sampleUrl": "http://192.168.9.105:3000",
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-09-25T03:58:05.375Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
