# fbi-generalize-interlayer 

使用nodemo 建立热更新
使用apidoc 建立开发接口文档